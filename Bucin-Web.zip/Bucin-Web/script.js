function showLove() {
  const message = document.getElementById("loveMessage");
  message.textContent = "Aku sayang kamu lebih dari apapun! 💘💘💘";
}